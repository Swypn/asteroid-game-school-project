#include "ufo.h"

void Ufo::SetUp(Screen& p_screen)
{

}
void Ufo::Update(Screen& p_screen)
{

}
void Ufo::Render(Screen& p_screen)
{

}