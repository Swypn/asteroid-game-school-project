#include "asteroid.h"

void Asteroid::SetUp(Screen& p_screen)
{

}
void Asteroid::Update(Screen& p_screen)
{

}
void Asteroid::Render(Screen& p_screen)
{

}