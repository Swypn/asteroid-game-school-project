#include "bullet.h"

void BulletManager::SetUp(Screen& p_screen)
{

}
void BulletManager::Update(Screen& p_screen)
{

}
void BulletManager::Render(Screen& p_screen)
{

}